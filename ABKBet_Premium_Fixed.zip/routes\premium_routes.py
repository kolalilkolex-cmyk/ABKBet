from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.extensions import db
from app.models import User
from app.models.premium_booking import PremiumBooking, PremiumBookingPurchase
from app.models import Match
from datetime import datetime, timedelta
from sqlalchemy import and_
import logging

logger = logging.getLogger(__name__)
premium_bp = Blueprint('premium', __name__, url_prefix='/api/premium')

@premium_bp.route('/admin/create-booking', methods=['POST'])
@jwt_required()
def create_premium_booking():
    """Admin creates a premium booking code"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or not user.is_admin:
            return jsonify({'error': 'Admin access required'}), 403
        
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
            
        selections = data.get('selections', [])  # [{match_id, market, selection, odds}]
        description = data.get('description', '')
        price_usd = float(data.get('price_usd', 250.0))
        expires_hours = data.get('expires_hours')  # Optional expiration in hours
        
        if not selections or len(selections) == 0:
            return jsonify({'error': 'At least one selection is required'}), 400
        
        # Calculate total odds
        total_odds = 1.0
        for sel in selections:
            total_odds *= float(sel.get('odds', 1.0))
        
        # Generate unique booking code
        booking_code = PremiumBooking.generate_code()
        
        # Create expiration date if specified
        expires_at = None
        if expires_hours:
            expires_at = datetime.utcnow() + timedelta(hours=int(expires_hours))
        
        # Create premium booking
        booking = PremiumBooking(
            booking_code=booking_code,
            selections=selections,
            total_odds=round(total_odds, 2),
            price_usd=price_usd,
            created_by_admin_id=current_user_id,
            description=description,
            expires_at=expires_at
        )
        
        db.session.add(booking)
        db.session.commit()
        
        return jsonify({
            'message': 'Premium booking created successfully',
            'booking': booking.to_dict(include_selections=True)
        }), 201
    except Exception as e:
        logger.error(f"Error creating premium booking: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@premium_bp.route('/check-code/<code>', methods=['GET'])
@jwt_required()
def check_premium_code(code):
    """Check if a premium booking code exists and user access"""
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    booking = PremiumBooking.query.filter_by(booking_code=code.upper()).first()
    
    if not booking:
        return jsonify({'error': 'Invalid booking code'}), 404
    
    # Check if expired
    if booking.expires_at and booking.expires_at < datetime.utcnow():
        return jsonify({'error': 'This booking code has expired'}), 410
    
    if booking.status != 'active':
        return jsonify({'error': f'This booking code is {booking.status}'}), 400
    
    # Convert user balance to USD (1 BTC = $45,000)
    BTC_PRICE_USD = 45000.0
    user_balance_usd = user.balance * BTC_PRICE_USD
    
    # Check if user already purchased
    purchase = PremiumBookingPurchase.query.filter_by(
        booking_id=booking.id,
        user_id=current_user_id
    ).first()
    
    has_access = purchase is not None
    
    # NEW LOGIC: Users with balance >= $250 can see premium codes
    # Users with balance < $250 need to deposit first to unlock selections
    if user_balance_usd >= 250.0:
        # User has enough balance - can see code and purchase
        requires_deposit = False
        can_purchase = not has_access  # Can purchase if not already purchased
    else:
        # User balance < $250 - needs to deposit to unlock selections
        requires_deposit = True
        can_purchase = False
        # Hide selections until they deposit enough
        if not has_access:
            has_access = False  # Force locked state
    
    return jsonify({
        'booking': booking.to_dict(include_selections=has_access),
        'has_access': has_access,
        'already_purchased': purchase is not None,
        'requires_deposit': requires_deposit,
        'can_purchase': can_purchase,
        'user_balance_usd': round(user_balance_usd, 2),
        'minimum_balance_required': 250.0,
        'deposit_needed': max(0, 250.0 - user_balance_usd) if user_balance_usd < 250.0 else 0
    }), 200


@premium_bp.route('/purchase/<code>', methods=['POST'])
@jwt_required()
def purchase_premium_booking(code):
    """Purchase access to a premium booking code"""
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        booking = PremiumBooking.query.filter_by(booking_code=code.upper()).first()
        
        if not booking:
            return jsonify({'error': 'Invalid booking code'}), 404
        
        # Check if expired
        if booking.expires_at and booking.expires_at < datetime.utcnow():
            return jsonify({'error': 'This booking code has expired'}), 410
        
        if booking.status != 'active':
            return jsonify({'error': f'This booking code is {booking.status}'}), 400
        
        # Check if already purchased
        existing_purchase = PremiumBookingPurchase.query.filter_by(
            booking_id=booking.id,
            user_id=current_user_id
        ).first()
        
        if existing_purchase:
            return jsonify({'error': 'You have already purchased this booking'}), 400
        
        # Use a fixed BTC price for conversions (can be updated manually or via config)
        BTC_PRICE_USD = 45000.0  # Fixed rate for now
        
        # Convert user's BTC balance to USD
        user_balance_usd = user.balance * BTC_PRICE_USD
        
        # NEW RESTRICTION: User must have at least $250 balance to purchase
        if user_balance_usd < 250.0:
            return jsonify({
                'error': 'You need at least $250 balance to purchase premium codes',
                'your_balance_usd': round(user_balance_usd, 2),
                'required_minimum_balance': 250.0,
                'deposit_needed': round(250.0 - user_balance_usd, 2)
            }), 403
        
        # Check if user has enough balance for the purchase price
        if user_balance_usd < booking.price_usd:
            return jsonify({
                'error': 'Insufficient balance',
                'required_usd': booking.price_usd,
                'current_balance_usd': round(user_balance_usd, 2),
                'current_balance_btc': user.balance
            }), 400
        
        # Deduct BTC equivalent from user balance
        required_btc = booking.price_usd / BTC_PRICE_USD
        user.balance -= required_btc
        
        # Create purchase record
        purchase = PremiumBookingPurchase(
            booking_id=booking.id,
            user_id=current_user_id,
            amount_paid_usd=booking.price_usd,
            payment_method='balance'
        )
        
        db.session.add(purchase)
        db.session.commit()
        
        return jsonify({
            'message': 'Premium booking purchased successfully',
            'booking': booking.to_dict(include_selections=True),
            'new_balance_btc': user.balance
        }), 200
    except Exception as e:
        logger.error(f"Error purchasing premium booking: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@premium_bp.route('/admin/bookings', methods=['GET'])
@jwt_required()
def get_admin_bookings():
    """Get all premium bookings (admin only)"""
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if not user or not user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    bookings = PremiumBooking.query.order_by(PremiumBooking.created_at.desc()).all()
    
    bookings_data = []
    for booking in bookings:
        booking_dict = booking.to_dict(include_selections=True)
        booking_dict['purchases_count'] = len(booking.purchases)
        booking_dict['revenue'] = len(booking.purchases) * booking.price_usd
        bookings_data.append(booking_dict)
    
    return jsonify({'bookings': bookings_data}), 200


@premium_bp.route('/admin/booking/<int:booking_id>', methods=['DELETE'])
@jwt_required()
def delete_premium_booking(booking_id):
    """Cancel/delete a premium booking (admin only)"""
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if not user or not user.is_admin:
        return jsonify({'error': 'Admin access required'}), 403
    
    booking = PremiumBooking.query.get(booking_id)
    if not booking:
        return jsonify({'error': 'Booking not found'}), 404
    
    booking.status = 'cancelled'
    db.session.commit()
    
    return jsonify({'message': 'Premium booking cancelled'}), 200


@premium_bp.route('/my-purchases', methods=['GET'])
@jwt_required()
def get_my_purchases():
    """Get user's purchased premium bookings"""
    current_user_id = get_jwt_identity()
    
    purchases = PremiumBookingPurchase.query.filter_by(user_id=current_user_id).order_by(
        PremiumBookingPurchase.purchased_at.desc()
    ).all()
    
    purchases_data = []
    for purchase in purchases:
        booking_data = purchase.booking.to_dict(include_selections=True)
        booking_data['purchased_at'] = purchase.purchased_at.isoformat()
        booking_data['amount_paid_usd'] = purchase.amount_paid_usd
        purchases_data.append(booking_data)
    
    return jsonify({'purchases': purchases_data}), 200
