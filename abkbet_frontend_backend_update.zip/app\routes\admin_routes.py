from flask import Blueprint, request, jsonify, current_app
from app.models import db, Bet, User, Transaction, BetStatus, Match, MatchStatus
from app.services.betting_service import BettingService
from app.utils.decorators import token_required
import logging, os, uuid
from datetime import datetime

logger = logging.getLogger(__name__)
admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')
betting_service = BettingService()

# --- Admin check decorator ---
def admin_required(f):
    @token_required
    def wrapper(user, *args, **kwargs):
        if not getattr(user, 'is_admin', False):
            return jsonify({'message': 'Admin access required'}), 403
        return f(user, *args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

# --- Platform Statistics ---
@admin_bp.route('/statistics', methods=['GET'])
@admin_required
def get_platform_statistics(user):
    try:
        total_users = User.query.count()
        active_bets = Bet.query.filter_by(status=BetStatus.ACTIVE.value).count()
        total_volume_btc = db.session.query(db.func.sum(Bet.amount)).scalar() or 0
        total_payouts_btc = db.session.query(db.func.sum(Bet.settled_payout)).scalar() or 0
        pending_deposits = Transaction.query.filter_by(transaction_type='deposit', status='pending').count()
        pending_withdrawals = Transaction.query.filter_by(transaction_type='withdrawal', status='pending').count()

        # Convert BTC to USD for easier accounting (1 BTC = $50,000)
        BTC_TO_USD = 50000
        total_volume_usd = total_volume_btc * BTC_TO_USD
        total_payouts_usd = total_payouts_btc * BTC_TO_USD

        return jsonify({
            'total_users': total_users,
            'active_bets': active_bets,
            'total_volume': total_volume_usd,
            'total_payouts': total_payouts_usd,
            'pending_deposits': pending_deposits,
            'pending_withdrawals': pending_withdrawals
        }), 200
    except Exception as e:
        logger.error(f"[Platform Stats] Error: {e}")
        return jsonify({'message': 'Error fetching statistics'}), 500

# --- Recent Activity ---
@admin_bp.route('/activity/recent', methods=['GET'])
@admin_required
def get_recent_activity(user):
    """Get combined recent activity from bets, transactions, and users"""
    try:
        limit = request.args.get('limit', 20, type=int)
        activities = []
        
        # Recent Bets
        recent_bets = Bet.query.order_by(Bet.created_at.desc()).limit(limit).all()
        for bet in recent_bets:
            activities.append({
                'time': bet.created_at.isoformat(),
                'type': 'bet_placed',
                'user': bet.user.username,
                'amount': bet.amount,
                'status': bet.status,
                'description': f"Placed bet at {bet.odds}x odds"
            })
        
        # Recent Transactions
        recent_txs = Transaction.query.order_by(Transaction.created_at.desc()).limit(limit).all()
        for tx in recent_txs:
            activities.append({
                'time': tx.created_at.isoformat(),
                'type': tx.transaction_type,
                'user': tx.user.username,
                'amount': tx.amount,
                'status': tx.status,
                'description': f"{tx.transaction_type.title()} transaction"
            })
        
        # Recent Bet Settlements
        recent_settled = Bet.query.filter(Bet.settled_at.isnot(None)).order_by(Bet.settled_at.desc()).limit(limit).all()
        for bet in recent_settled:
            activities.append({
                'time': bet.settled_at.isoformat(),
                'type': 'bet_settled',
                'user': bet.user.username,
                'amount': bet.settled_payout if bet.settled_payout else 0,
                'status': bet.result,
                'description': f"Bet {bet.result}: {bet.settled_payout or 0:.8f} BTC"
            })
        
        # Recent User Registrations
        recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
        for u in recent_users:
            activities.append({
                'time': u.created_at.isoformat(),
                'type': 'user_registered',
                'user': u.username,
                'amount': 0,
                'status': 'active' if u.is_active else 'inactive',
                'description': 'New user registration'
            })
        
        # Sort by time descending and limit
        activities.sort(key=lambda x: x['time'], reverse=True)
        activities = activities[:limit]
        
        return jsonify({'activities': activities}), 200
    except Exception as e:
        logger.error(f"[Recent Activity] Error: {e}")
        return jsonify({'message': 'Error fetching recent activity'}), 500

# --- Pending Deposits ---
@admin_bp.route('/deposits/pending', methods=['GET'])
@admin_required
def get_pending_deposits(user):
    try:
        deposits = Transaction.query.filter_by(
            transaction_type='deposit',
            status='pending'
        ).order_by(Transaction.created_at.desc()).all()

        return jsonify({
            'deposits': [{
                'id': tx.id,
                'user_id': tx.user_id,
                'username': tx.user.username,
                'amount': tx.amount,
                'payment_method': tx.payment_method,
                'tx_hash': tx.tx_hash,
                'created_at': tx.created_at.isoformat()
            } for tx in deposits]
        }), 200
    except Exception as e:
        logger.error(f"[Pending Deposits] Error: {e}")
        return jsonify({'message': 'Error fetching pending deposits'}), 500

# --- Approve Deposit ---
@admin_bp.route('/deposits/<int:tx_id>/approve', methods=['POST'])
@admin_required
def approve_deposit(user, tx_id):
    try:
        transaction = db.session.get(Transaction, tx_id)
        if not transaction:
            return jsonify({'message': 'Transaction not found'}), 404

        if transaction.status != 'pending':
            return jsonify({'message': 'Transaction is not pending'}), 400

        # Update transaction
        transaction.status = 'completed'
        
        # Credit user balance
        target_user = db.session.get(User, transaction.user_id)
        if target_user:
            target_user.balance += transaction.amount

        db.session.commit()

        logger.info(f"Admin {user.username} approved deposit {tx_id} for user {target_user.username}")

        return jsonify({
            'message': 'Deposit approved successfully',
            'transaction_id': tx_id,
            'user_balance': target_user.balance
        }), 200
    except Exception as e:
        logger.error(f"[Approve Deposit] Error: {e}")
        db.session.rollback()
        return jsonify({'message': 'Error approving deposit'}), 500

# --- Reject Deposit ---
@admin_bp.route('/deposits/<int:tx_id>/reject', methods=['POST'])
@admin_required
def reject_deposit(user, tx_id):
    try:
        transaction = db.session.get(Transaction, tx_id)
        if not transaction:
            return jsonify({'message': 'Transaction not found'}), 404

        if transaction.status != 'pending':
            return jsonify({'message': 'Transaction is not pending'}), 400

        transaction.status = 'failed'
        db.session.commit()

        logger.info(f"Admin {user.username} rejected deposit {tx_id}")

        return jsonify({
            'message': 'Deposit rejected',
            'transaction_id': tx_id
        }), 200
    except Exception as e:
        logger.error(f"[Reject Deposit] Error: {e}")
        db.session.rollback()
        return jsonify({'message': 'Error rejecting deposit'}), 500

# --- Pending Withdrawals ---
@admin_bp.route('/withdrawals/pending', methods=['GET'])
@admin_required
def get_pending_withdrawals(user):
    try:
        withdrawals = Transaction.query.filter_by(
            transaction_type='withdrawal',
            status='pending'
        ).order_by(Transaction.created_at.desc()).all()

        return jsonify({
            'withdrawals': [{
                'id': tx.id,
                'user_id': tx.user_id,
                'username': tx.user.username,
                'amount': tx.amount,
                'to_address': tx.to_address,
                'created_at': tx.created_at.isoformat()
            } for tx in withdrawals]
        }), 200
    except Exception as e:
        logger.error(f"[Pending Withdrawals] Error: {e}")
        return jsonify({'message': 'Error fetching pending withdrawals'}), 500

# --- Process Withdrawal ---
@admin_bp.route('/withdrawals/<int:tx_id>/process', methods=['POST'])
@admin_required
def process_withdrawal(user, tx_id):
    try:
        data = request.get_json()
        blockchain_tx_hash = data.get('tx_hash')  # Actual blockchain transaction hash

        transaction = db.session.get(Transaction, tx_id)
        if not transaction:
            return jsonify({'message': 'Transaction not found'}), 404

        if transaction.status != 'pending':
            return jsonify({'message': 'Transaction is not pending'}), 400

        # Update with actual blockchain hash
        if blockchain_tx_hash:
            transaction.tx_hash = blockchain_tx_hash
        transaction.status = 'completed'
        
        db.session.commit()

        logger.info(f"Admin {user.username} processed withdrawal {tx_id}")

        return jsonify({
            'message': 'Withdrawal processed successfully',
            'transaction_id': tx_id,
            'tx_hash': transaction.tx_hash
        }), 200
    except Exception as e:
        logger.error(f"[Process Withdrawal] Error: {e}")
        db.session.rollback()
        return jsonify({'message': 'Error processing withdrawal'}), 500

# --- Adjust User Balance ---
@admin_bp.route('/users/<int:user_id>/balance', methods=['POST'])
@admin_required
def adjust_user_balance(user, user_id):
    try:
        data = request.get_json()
        amount = data.get('amount')
        reason = data.get('reason', 'Admin adjustment')

        if amount is None:
            return jsonify({'message': 'Amount is required'}), 400

        target_user = db.session.get(User, user_id)
        if not target_user:
            return jsonify({'message': 'User not found'}), 404

        old_balance = target_user.balance
        target_user.balance += float(amount)
        
        # Create transaction record
        transaction = Transaction(
            user_id=user_id,
            amount=abs(float(amount)),
            transaction_type='deposit' if amount > 0 else 'withdrawal',
            status='completed',
            tx_hash=f'ADMIN_ADJ_{uuid.uuid4().hex[:8]}',
            from_address='ADMIN',
            to_address=target_user.username,
            payment_method='admin_adjustment'
        )
        db.session.add(transaction)
        db.session.commit()

        logger.info(f"Admin {user.username} adjusted balance for {target_user.username}: {amount}. Reason: {reason}")

        return jsonify({
            'message': 'Balance adjusted successfully',
            'old_balance': old_balance,
            'new_balance': target_user.balance
        }), 200
    except Exception as e:
        logger.error(f"[Adjust Balance] Error: {e}")
        db.session.rollback()
        return jsonify({'message': 'Error adjusting balance'}), 500

# --- Settle Bet ---
@admin_bp.route('/bets/<int:bet_id>/settle', methods=['POST'])
@admin_required
def settle_bet(user, bet_id):
    try:
        data = request.get_json()
        result = data.get('result')
        payout = data.get('payout')

        if not result:
            return jsonify({'message': 'Missing result field'}), 400

        bet = db.session.get(Bet, bet_id)
        if not bet:
            return jsonify({'message': 'Bet not found'}), 404

        success = betting_service.settle_bet(bet, result, payout)
        if success:
            return jsonify({
                'message': 'Bet settled successfully',
                'bet': {
                    'id': bet.id,
                    'result': bet.result,
                    'settled_payout': bet.settled_payout
                }
            }), 200
        return jsonify({'message': 'Failed to settle bet'}), 400

    except Exception as e:
        logger.error(f"[Settle Bet] Error for bet_id={bet_id}: {e}")
        return jsonify({'message': 'An error occurred'}), 500

# --- List Users ---
@admin_bp.route('/users', methods=['GET'])
@admin_required
def list_users(user):
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        users = User.query.paginate(page=page, per_page=per_page)

        return jsonify({
            'users': [{
                'id': u.id,
                'username': u.username,
                'email': u.email,
                'balance': u.balance,
                'created_at': u.created_at.isoformat()
            } for u in users.items],
            'total': users.total,
            'pages': users.pages,
            'current_page': page,
            'per_page': per_page
        }), 200
    except Exception as e:
        logger.error(f"[List Users] Error: {e}")
        return jsonify({'message': 'Error fetching users'}), 500

# --- Get User Details ---
@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@admin_required
def get_user_details(user, user_id):
    try:
        target_user = db.session.get(User, user_id)
        if not target_user:
            return jsonify({'message': 'User not found'}), 404

        stats = betting_service.get_user_statistics(target_user)
        return jsonify({
            'user': {
                'id': target_user.id,
                'username': target_user.username,
                'email': target_user.email,
                'balance': target_user.balance,
                'created_at': target_user.created_at.isoformat(),
                'statistics': stats
            }
        }), 200
    except Exception as e:
        logger.error(f"[User Details] Error for user_id={user_id}: {e}")
        return jsonify({'message': 'Error fetching user details'}), 500

# --- List Transactions ---
@admin_bp.route('/transactions', methods=['GET'])
@admin_required
def list_transactions(user):
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        status = request.args.get('status')

        query = Transaction.query
        if status:
            query = query.filter_by(status=status)

        transactions = query.order_by(Transaction.created_at.desc()).paginate(page=page, per_page=per_page)

        return jsonify({
            'transactions': [{
                'id': tx.id,
                'user_id': tx.user_id,
                'username': tx.user.username,
                'tx_hash': tx.tx_hash,
                'amount': tx.amount,
                'type': tx.transaction_type,
                'status': tx.status,
                'created_at': tx.created_at.isoformat()
            } for tx in transactions.items],
            'total': transactions.total,
            'pages': transactions.pages,
            'current_page': page,
            'per_page': per_page
        }), 200
    except Exception as e:
        logger.error(f"[List Transactions] Error: {e}")
        return jsonify({'message': 'Error fetching transactions'}), 500

# --- List All Bets ---
@admin_bp.route('/bets', methods=['GET'])
@admin_required
def list_bets(user):
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        status = request.args.get('status')

        query = Bet.query
        if status:
            query = query.filter_by(status=status)

        bets = query.order_by(Bet.created_at.desc()).paginate(page=page, per_page=per_page)

        return jsonify({
            'bets': [{
                'id': bet.id,
                'user_id': bet.user_id,
                'username': bet.user.username,
                'amount': bet.amount,
                'odds': bet.odds,
                'potential_payout': bet.potential_payout,
                'event_description': bet.event_description,
                'status': bet.status,
                'result': bet.result,
                'settled_payout': bet.settled_payout,
                'created_at': bet.created_at.isoformat(),
                'settled_at': bet.settled_at.isoformat() if bet.settled_at else None
            } for bet in bets.items],
            'total': bets.total,
            'pages': bets.pages,
            'current_page': page,
            'per_page': per_page
        }), 200
    except Exception as e:
        logger.error(f"[List Bets] Error: {e}")
        return jsonify({'message': 'Error fetching bets'}), 500

# ===== MATCH MANAGEMENT =====

# --- List All Matches (Manual Only) ---
@admin_bp.route('/matches', methods=['GET'])
@admin_required
def list_matches(user):
    """Get all manually managed matches"""
    try:
        # Only show manual matches (not API-based ones)
        matches = Match.query.filter_by(is_manual=True).order_by(Match.match_date.desc()).all()
        
        return jsonify({
            'matches': [match.to_dict() for match in matches]
        }), 200
    except Exception as e:
        logger.error(f"[List Matches] Error: {e}")
        return jsonify({'message': 'Error fetching matches'}), 500

# --- Create New Match ---
@admin_bp.route('/matches', methods=['POST'])
@admin_required
def create_match(user):
    """Create a new manually managed match"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['home_team', 'away_team', 'match_date', 'home_odds', 'draw_odds', 'away_odds']
        if not all(field in data for field in required_fields):
            return jsonify({'message': 'Missing required fields'}), 400
        
        # Parse date
        try:
            match_date = datetime.fromisoformat(data['match_date'].replace('Z', '+00:00'))
        except:
            return jsonify({'message': 'Invalid date format'}), 400
        
        # Create match
        match = Match(
            home_team=data['home_team'],
            away_team=data['away_team'],
            league=data.get('league'),
            match_date=match_date,
            home_odds=float(data['home_odds']),
            draw_odds=float(data['draw_odds']),
            away_odds=float(data['away_odds']),
            # Optional betting markets
            home_draw_odds=float(data['home_draw_odds']) if 'home_draw_odds' in data else None,
            home_away_odds=float(data['home_away_odds']) if 'home_away_odds' in data else None,
            draw_away_odds=float(data['draw_away_odds']) if 'draw_away_odds' in data else None,
            gg_odds=float(data['gg_odds']) if 'gg_odds' in data else None,
            ng_odds=float(data['ng_odds']) if 'ng_odds' in data else None,
            over15_odds=float(data['over15_odds']) if 'over15_odds' in data else None,
            under15_odds=float(data['under15_odds']) if 'under15_odds' in data else None,
            over25_odds=float(data['over25_odds']) if 'over25_odds' in data else None,
            under25_odds=float(data['under25_odds']) if 'under25_odds' in data else None,
            over35_odds=float(data['over35_odds']) if 'over35_odds' in data else None,
            under35_odds=float(data['under35_odds']) if 'under35_odds' in data else None,
            # HT/FT and Correct Score (as JSON strings)
            htft_odds=data.get('htft_odds'),
            correct_score_odds=data.get('correct_score_odds'),
            status=MatchStatus.SCHEDULED.value,
            is_manual=True
        )
        
        db.session.add(match)
        db.session.commit()
        
        logger.info(f"Admin {user.username} created match: {match.home_team} vs {match.away_team}")
        
        return jsonify({
            'message': 'Match created successfully',
            'match': match.to_dict()
        }), 201
    except Exception as e:
        logger.error(f"[Create Match] Error: {e}")
        db.session.rollback()
        return jsonify({'message': 'Error creating match'}), 500

# --- Get Single Match ---
@admin_bp.route('/matches/<int:match_id>', methods=['GET'])
@admin_required
def get_match(user, match_id):
    """Get details of a specific match"""
    try:
        match = db.session.get(Match, match_id)
        if not match:
            return jsonify({'message': 'Match not found'}), 404
        
        return jsonify({'match': match.to_dict()}), 200
    except Exception as e:
        logger.error(f"[Get Match] Error: {e}")
        return jsonify({'message': 'Error fetching match'}), 500

# --- Update Match ---
@admin_bp.route('/matches/<int:match_id>', methods=['PUT'])
@admin_required
def update_match(user, match_id):
    """Update match details (teams, odds, date, etc.)"""
    try:
        match = db.session.get(Match, match_id)
        if not match:
            return jsonify({'message': 'Match not found'}), 404
        
        if not match.is_manual:
            return jsonify({'message': 'Cannot edit API-based matches'}), 403
        
        data = request.get_json()
        
        # Update fields
        if 'home_team' in data:
            match.home_team = data['home_team']
        if 'away_team' in data:
            match.away_team = data['away_team']
        if 'league' in data:
            match.league = data['league']
        if 'match_date' in data:
            try:
                match.match_date = datetime.fromisoformat(data['match_date'].replace('Z', '+00:00'))
            except:
                return jsonify({'message': 'Invalid date format'}), 400
        if 'home_odds' in data:
            match.home_odds = float(data['home_odds'])
        if 'draw_odds' in data:
            match.draw_odds = float(data['draw_odds'])
        if 'away_odds' in data:
            match.away_odds = float(data['away_odds'])
        
        db.session.commit()
        
        logger.info(f"Admin {user.username} updated match {match_id}")
        
        return jsonify({
            'message': 'Match updated successfully',
            'match': match.to_dict()
        }), 200
    except Exception as e:
        logger.error(f"[Update Match] Error: {e}")
        db.session.rollback()
        return jsonify({'message': 'Error updating match'}), 500

# --- Update Match Result ---
@admin_bp.route('/matches/<int:match_id>/result', methods=['POST'])
@admin_required
def update_match_result(user, match_id):
    """Update match score and status, settle related bets"""
    try:
        match = db.session.get(Match, match_id)
        if not match:
            return jsonify({'message': 'Match not found'}), 404
        
        data = request.get_json()
        
        # Check if this is halftime or fulltime result
        if 'ht_home_score' in data or 'ht_away_score' in data:
            # Update halftime score
            if 'ht_home_score' in data:
                match.ht_home_score = int(data['ht_home_score'])
            if 'ht_away_score' in data:
                match.ht_away_score = int(data['ht_away_score'])
            if 'ht_status' in data:
                match.ht_status = data['ht_status']
            
            db.session.commit()
            logger.info(f"Admin {user.username} updated half-time result for match {match_id}")
            
            return jsonify({
                'message': 'Half-time result updated successfully',
                'match': match.to_dict()
            }), 200
        
        # Update fulltime score and status
        if 'home_score' in data:
            match.home_score = int(data['home_score'])
        if 'away_score' in data:
            match.away_score = int(data['away_score'])
        if 'status' in data:
            match.status = data['status']
        
        # If match is finished, settle all bets
        if match.status == MatchStatus.FINISHED.value and match.home_score is not None and match.away_score is not None:
            # Settle all bets on this match (both by match_id and by description matching)
            match_name = f"{match.home_team} vs {match.away_team}"
            match_name_alt = f"{match.home_team} vs. {match.away_team}"
            
            # Find bets by match_id or by matching the match name in description
            bets = Bet.query.filter(
                Bet.status == BetStatus.ACTIVE.value,
                db.or_(
                    Bet.match_id == match_id,
                    Bet.event_description.like(f'%{match_name}%'),
                    Bet.event_description.like(f'%{match_name_alt}%')
                )
            ).all()
            
            settled_count = 0
            for bet in bets:
                is_won = False
                
                # Parse the bet to determine if it won
                desc = bet.event_description
                market = bet.market_type or ''
                
                # Extract selection from description (e.g., "[Match Result] home @2.00")
                selection_match = None
                if '[Match Result]' in desc or '1x2' in market.lower():
                    if ' home @' in desc.lower() or '] home @' in desc.lower():
                        selection_match = 'home'
                    elif ' away @' in desc.lower() or '] away @' in desc.lower():
                        selection_match = 'away'
                    elif ' draw @' in desc.lower() or '] draw @' in desc.lower():
                        selection_match = 'draw'
                    
                    # Check if won
                    if match.home_score > match.away_score and selection_match == 'home':
                        is_won = True
                    elif match.away_score > match.home_score and selection_match == 'away':
                        is_won = True
                    elif match.home_score == match.away_score and selection_match == 'draw':
                        is_won = True
                
                # Handle Over/Under markets
                elif 'over/under' in desc.lower() or 'ou' in market.lower():
                    total_goals = match.home_score + match.away_score
                    if 'under' in desc.lower():
                        if '1.5' in desc and total_goals < 1.5:
                            is_won = True
                        elif '2.5' in desc and total_goals < 2.5:
                            is_won = True
                        elif '3.5' in desc and total_goals < 3.5:
                            is_won = True
                    elif 'over' in desc.lower():
                        if '1.5' in desc and total_goals > 1.5:
                            is_won = True
                        elif '2.5' in desc and total_goals > 2.5:
                            is_won = True
                        elif '3.5' in desc and total_goals > 3.5:
                            is_won = True
                
                # Handle Both Teams Score (GG/NG)
                elif 'both teams score' in desc.lower() or 'gg' in market.lower():
                    both_scored = match.home_score > 0 and match.away_score > 0
                    if ('yes' in desc.lower() or ' gg ' in desc.lower()) and both_scored:
                        is_won = True
                    elif ('no' in desc.lower() or ' ng ' in desc.lower()) and not both_scored:
                        is_won = True
                
                # Handle Correct Score
                elif 'correct score' in desc.lower() or 'cs' in market.lower():
                    score_pattern = f"{match.home_score}-{match.away_score}"
                    if score_pattern in desc:
                        is_won = True
                
                # Handle HT/FT (Half Time/Full Time)
                elif 'half time/full time' in desc.lower() or 'htft' in market.lower() or 'ht/ft' in desc.lower():
                    if match.ht_home_score is not None and match.ht_away_score is not None:
                        # Determine HT result
                        if match.ht_home_score > match.ht_away_score:
                            ht_result = 'h'
                        elif match.ht_away_score > match.ht_home_score:
                            ht_result = 'a'
                        else:
                            ht_result = 'd'
                        
                        # Determine FT result
                        if match.home_score > match.away_score:
                            ft_result = 'h'
                        elif match.away_score > match.home_score:
                            ft_result = 'a'
                        else:
                            ft_result = 'd'
                        
                        actual_result = f"{ht_result}{ft_result}"
                        
                        # Check if bet matches (e.g., "hh", "ad", "dd")
                        if f' {actual_result} @' in desc.lower() or f'] {actual_result} @' in desc.lower():
                            is_won = True
                
                # Handle Double Chance
                elif 'double chance' in desc.lower() or 'dc' in market.lower():
                    if match.home_score > match.away_score:
                        # Home win
                        if '1x' in desc.lower() or 'home/draw' in desc.lower():
                            is_won = True
                        elif '12' in desc.lower() or 'home/away' in desc.lower():
                            is_won = True
                    elif match.away_score > match.home_score:
                        # Away win
                        if 'x2' in desc.lower() or 'draw/away' in desc.lower():
                            is_won = True
                        elif '12' in desc.lower() or 'home/away' in desc.lower():
                            is_won = True
                    else:
                        # Draw
                        if '1x' in desc.lower() or 'home/draw' in desc.lower():
                            is_won = True
                        elif 'x2' in desc.lower() or 'draw/away' in desc.lower():
                            is_won = True
                
                # Apply result
                if is_won:
                    bet.status = BetStatus.WON.value
                    bet.result = 'win'
                    bet.settled_payout = bet.potential_payout
                    bet.user.balance += bet.settled_payout
                else:
                    bet.status = BetStatus.LOST.value
                    bet.result = 'loss'
                    bet.settled_payout = 0
                
                bet.settled_at = datetime.utcnow()
                settled_count += 1
            
            logger.info(f"Admin {user.username} settled {settled_count} bets for match {match_id}")
        
        db.session.commit()
        
        return jsonify({
            'message': 'Match result updated successfully',
            'match': match.to_dict()
        }), 200
    except Exception as e:
        logger.error(f"[Update Match Result] Error: {e}")
        db.session.rollback()
        return jsonify({'message': f'Error updating match result: {str(e)}'}), 500

# --- Delete Match ---
@admin_bp.route('/matches/<int:match_id>', methods=['DELETE'])
@admin_required
def delete_match(user, match_id):
    """Delete a match (only if no bets placed)"""
    try:
        match = db.session.get(Match, match_id)
        if not match:
            return jsonify({'message': 'Match not found'}), 404
        
        if not match.is_manual:
            return jsonify({'message': 'Cannot delete API-based matches'}), 403
        
        # Check if there are any bets on this match
        bet_count = Bet.query.filter_by(match_id=match_id).count()
        if bet_count > 0:
            return jsonify({'message': f'Cannot delete match with {bet_count} existing bets'}), 400
        
        db.session.delete(match)
        db.session.commit()
        
        logger.info(f"Admin {user.username} deleted match {match_id}")
        
        return jsonify({'message': 'Match deleted successfully'}), 200
    except Exception as e:
        logger.error(f"[Delete Match] Error: {e}")
        db.session.rollback()
        return jsonify({'message': 'Error deleting match'}), 500
