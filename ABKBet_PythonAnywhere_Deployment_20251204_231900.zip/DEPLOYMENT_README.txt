﻿# PythonAnywhere Deployment Instructions

## 1. Upload Files
Upload all files in this folder to: /home/YOUR_USERNAME/ABKBet/

## 2. Install Dependencies
In PythonAnywhere Bash console:
`ash
cd ~/ABKBet
python3.10 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
`

## 3. Initialize Database
`ash
cd ~/ABKBet
source venv/bin/activate
python init_db.py
`

## 4. Configure WSGI
Edit your WSGI file at /var/www/YOUR_USERNAME_pythonanywhere_com_wsgi.py:
`python
import sys
import os

project_home = '/home/YOUR_USERNAME/ABKBet'
if project_home not in sys.path:
    sys.path = [project_home] + sys.path

os.environ['SECRET_KEY'] = 'your-secret-key-change-this'
os.environ['FOOTBALL_API_KEY'] = '8a0943a24d4c44f4f5d8a091f6348e9f'
os.environ['FOOTBALL_API_ENABLED'] = 'true'

from run import app as application
`

## 5. Reload Web App
Click "Reload" button on Web tab

## 6. Test Login/Register
Your site: https://YOUR_USERNAME.pythonanywhere.com

## Login/Register Fix Applied:
- CORS headers configured
- JWT token handling fixed
- Session management improved
- API endpoints corrected
