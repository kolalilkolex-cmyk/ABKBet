import os
from datetime import timedelta

class Config:
    """Base configuration"""
    FLASK_ENV = os.getenv('FLASK_ENV', 'development')
    TESTING = False
    
    # Database
    # Use a canonical absolute path inside the Flask `instance/` folder so all
    # processes and scripts operate on the same sqlite file and avoid schema drift.
    instance_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'instance'))
    try:
        os.makedirs(instance_dir, exist_ok=True)
    except Exception:
        # best-effort; if creation fails, relative fallback will still work
        pass
    default_db = os.path.abspath(os.path.join(instance_dir, 'betting.db'))
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', f'sqlite:///{default_db}')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # JWT
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'dev-secret-key-change-in-production')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=30)
    
    # Bitcoin
    BITCOIN_NETWORK = os.getenv('BITCOIN_NETWORK', 'testnet')
    BITCOIN_PRIVATE_KEY = os.getenv('BITCOIN_PRIVATE_KEY', '')
    
    # Webhook
    WEBHOOK_SECRET = os.getenv('WEBHOOK_SECRET', 'webhook-secret')
    
    # App Settings
    MIN_BET_AMOUNT = 0.001  # in BTC
    MAX_BET_AMOUNT = 10.0   # in BTC
    CONFIRMATION_REQUIRED = 1  # number of Bitcoin confirmations required
    
    # Currency
    BTC_TO_USD = 45000.0  # Current BTC/USD rate (can be updated from API)
    DISPLAY_CURRENCY = 'USD'  # Display currency to users
    
    # Email Configuration (optional - emails will be logged if not configured)
    SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
    SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
    SMTP_USERNAME = os.getenv('SMTP_USERNAME', '')
    SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', '')
    SMTP_FROM_EMAIL = os.getenv('SMTP_FROM_EMAIL', '')
    SMTP_FROM_NAME = os.getenv('SMTP_FROM_NAME', 'ABKBet')
    
    # Football API Configuration
    FOOTBALL_API_KEY = os.getenv('FOOTBALL_API_KEY', '')
    FOOTBALL_API_ENABLED = os.getenv('FOOTBALL_API_ENABLED', 'false').lower() == 'true'
    
    # Celery Configuration
    CELERY_BROKER_URL = os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0')
    CELERY_RESULT_BACKEND = os.getenv('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0')
    
    # Redis Configuration
    REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    
    # WebSocket Configuration
    SOCKETIO_MESSAGE_QUEUE = os.getenv('SOCKETIO_MESSAGE_QUEUE', 'redis://localhost:6379/0')

class DevelopmentConfig(Config):
    """Development configuration"""
    FLASK_DEBUG = True
    TESTING = False

class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=5)

class ProductionConfig(Config):
    """Production configuration"""
    FLASK_ENV = 'production'
    FLASK_DEBUG = False
    TESTING = False

config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
