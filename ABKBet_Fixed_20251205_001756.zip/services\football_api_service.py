"""
Football API Service - API-Football Integration
Fetches live matches, odds, and updates database
"""

import requests
import logging
from datetime import datetime, timedelta
from flask import current_app
from app.extensions import db
from app.models import Match, MatchStatus

logger = logging.getLogger(__name__)


class FootballAPIService:
    """Service to interact with API-Football"""
    
    BASE_URL = "https://v3.football.api-sports.io"
    
    def __init__(self):
        self.api_key = None
        self.headers = None
    
    def initialize(self, api_key):
        """Initialize the service with API key"""
        self.api_key = api_key
        self.headers = {
            'x-rapidapi-host': 'v3.football.api-sports.io',
            'x-rapidapi-key': api_key
        }
    
    def _make_request(self, endpoint, params=None):
        """Make a request to the API"""
        if not self.api_key:
            logger.error("Football API key not configured")
            return None
        
        try:
            url = f"{self.BASE_URL}/{endpoint}"
            response = requests.get(url, headers=self.headers, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if data.get('errors'):
                logger.error(f"API returned errors: {data['errors']}")
                return None
            
            return data.get('response', [])
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return None
    
    def get_live_matches(self):
        """Get all live matches"""
        return self._make_request('fixtures', {'live': 'all'})
    
    def get_today_matches(self, league_id=None):
        """Get today's matches, optionally filtered by league"""
        today = datetime.utcnow().strftime('%Y-%m-%d')
        params = {'date': today}
        if league_id:
            params['league'] = league_id
        return self._make_request('fixtures', params)
    
    def get_upcoming_matches(self, days=7, league_ids=None):
        """Get upcoming matches for the next N days"""
        today = datetime.utcnow()
        end_date = today + timedelta(days=days)
        
        # Free plan only has 2021-2023 data, use 2023
        season = 2023
        
        # If specific leagues requested, fetch each separately
        if league_ids:
            all_matches = []
            for league_id in league_ids:
                params = {
                    'league': league_id,
                    'season': season,
                    'from': '2023-08-01',
                    'to': '2023-12-31'
                }
                matches = self._make_request('fixtures', params)
                if matches:
                    all_matches.extend(matches)
                    # Limit to avoid excessive API calls
                    if len(all_matches) >= 50:
                        break
            return all_matches[:100]  # Return max 100 matches
        
        # Otherwise get today's matches across all leagues
        return self.get_today_matches()
    
    def get_match_odds(self, fixture_id):
        """Get odds for a specific match"""
        return self._make_request('odds', {'fixture': fixture_id})
    
    def sync_matches_to_database(self, matches_data):
        """
        Sync matches from API to database
        Returns: (created, updated) counts
        """
        if not matches_data:
            logger.warning("No matches data to sync")
            return 0, 0
        
        created = 0
        updated = 0
        
        for fixture in matches_data:
            try:
                fixture_id = fixture.get('fixture', {}).get('id')
                if not fixture_id:
                    continue
                
                teams = fixture.get('teams', {})
                home_team = teams.get('home', {}).get('name', 'Unknown')
                away_team = teams.get('away', {}).get('name', 'Unknown')
                
                league = fixture.get('league', {})
                league_name = league.get('name', 'Unknown League')
                
                fixture_info = fixture.get('fixture', {})
                match_date_str = fixture_info.get('date')
                match_date = datetime.fromisoformat(match_date_str.replace('Z', '+00:00')) if match_date_str else datetime.utcnow()
                
                status = fixture_info.get('status', {}).get('short', 'NS')
                match_status = self._map_api_status_to_db_status(status)
                
                # Get scores
                goals = fixture.get('goals', {})
                home_score = goals.get('home')
                away_score = goals.get('away')
                
                # Check if match exists
                existing_match = Match.query.filter_by(api_fixture_id=fixture_id).first()
                
                if existing_match:
                    # Update existing match
                    existing_match.home_team = home_team
                    existing_match.away_team = away_team
                    existing_match.league = league_name
                    existing_match.match_date = match_date
                    existing_match.status = match_status
                    existing_match.home_score = home_score
                    existing_match.away_score = away_score
                    existing_match.updated_at = datetime.utcnow()
                    updated += 1
                else:
                    # Create new match with default odds
                    new_match = Match(
                        home_team=home_team,
                        away_team=away_team,
                        league=league_name,
                        match_date=match_date,
                        status=match_status,
                        home_score=home_score,
                        away_score=away_score,
                        home_odds=2.0,
                        draw_odds=3.0,
                        away_odds=2.5,
                        is_manual=False,
                        api_fixture_id=fixture_id
                    )
                    db.session.add(new_match)
                    created += 1
            
            except Exception as e:
                logger.error(f"Error syncing match {fixture_id}: {e}")
                continue
        
        try:
            db.session.commit()
            logger.info(f"Synced matches: {created} created, {updated} updated")
        except Exception as e:
            db.session.rollback()
            logger.error(f"Database commit failed: {e}")
            return 0, 0
        
        return created, updated
    
    def update_match_odds(self, fixture_id, db_match_id):
        """
        Fetch and update odds for a specific match
        Returns: True if updated, False otherwise
        """
        odds_data = self.get_match_odds(fixture_id)
        
        if not odds_data:
            logger.warning(f"No odds data for fixture {fixture_id}")
            return False
        
        try:
            match = Match.query.get(db_match_id)
            if not match:
                logger.error(f"Match {db_match_id} not found in database")
                return False
            
            # API-Football returns odds from multiple bookmakers
            # We'll use the first bookmaker's odds or average them
            for odds_entry in odds_data:
                bookmakers = odds_entry.get('bookmakers', [])
                if not bookmakers:
                    continue
                
                # Get first bookmaker
                bookmaker = bookmakers[0]
                bets = bookmaker.get('bets', [])
                
                for bet in bets:
                    bet_name = bet.get('name', '')
                    values = bet.get('values', [])
                    
                    # Match Winner (1X2)
                    if bet_name == 'Match Winner':
                        for value in values:
                            odd_type = value.get('value')
                            odd_value = float(value.get('odd', 2.0))
                            
                            if odd_type == 'Home':
                                match.home_odds = odd_value
                            elif odd_type == 'Draw':
                                match.draw_odds = odd_value
                            elif odd_type == 'Away':
                                match.away_odds = odd_value
                    
                    # Over/Under 2.5
                    elif bet_name == 'Goals Over/Under' and '2.5' in str(values):
                        for value in values:
                            if 'Over 2.5' in value.get('value', ''):
                                match.over25_odds = float(value.get('odd', 1.8))
                            elif 'Under 2.5' in value.get('value', ''):
                                match.under25_odds = float(value.get('odd', 2.0))
                    
                    # Both Teams to Score
                    elif bet_name == 'Both Teams Score':
                        for value in values:
                            odd_type = value.get('value')
                            odd_value = float(value.get('odd', 1.8))
                            
                            if odd_type == 'Yes':
                                match.gg_odds = odd_value
                            elif odd_type == 'No':
                                match.ng_odds = odd_value
                
                # Break after processing first bookmaker
                break
            
            match.updated_at = datetime.utcnow()
            db.session.commit()
            logger.info(f"Updated odds for match {db_match_id}")
            return True
        
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating odds for match {db_match_id}: {e}")
            return False
    
    def _map_api_status_to_db_status(self, api_status):
        """Map API-Football status codes to our database status"""
        status_mapping = {
            'TBD': MatchStatus.SCHEDULED.value,
            'NS': MatchStatus.SCHEDULED.value,
            '1H': MatchStatus.LIVE.value,
            'HT': MatchStatus.LIVE.value,
            '2H': MatchStatus.LIVE.value,
            'ET': MatchStatus.LIVE.value,
            'P': MatchStatus.LIVE.value,
            'FT': MatchStatus.FINISHED.value,
            'AET': MatchStatus.FINISHED.value,
            'PEN': MatchStatus.FINISHED.value,
            'PST': MatchStatus.CANCELLED.value,
            'CANC': MatchStatus.CANCELLED.value,
            'ABD': MatchStatus.CANCELLED.value,
            'AWD': MatchStatus.FINISHED.value,
            'WO': MatchStatus.FINISHED.value
        }
        return status_mapping.get(api_status, MatchStatus.SCHEDULED.value)
    
    def get_popular_leagues(self):
        """Get list of popular league IDs for filtering"""
        return {
            'premier_league': 39,      # England - Premier League
            'la_liga': 140,            # Spain - La Liga
            'bundesliga': 78,          # Germany - Bundesliga
            'serie_a': 135,            # Italy - Serie A
            'ligue_1': 61,             # France - Ligue 1
            'champions_league': 2,     # UEFA Champions League
            'europa_league': 3,        # UEFA Europa League
            'world_cup': 1             # FIFA World Cup
        }


# Create global instance
football_api = FootballAPIService()
